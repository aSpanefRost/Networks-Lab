if [[ $EUID -ne 0 ]];
	then echo "Run the script in superuser mode using 'sudo su'"  #this portion checks if the 
         exit $1                                                  #user is in super user mode or not

fi


ip netns add H1                                      #adds the namespace H1
ip netns add H2                                      #adds the namespace H2
ip netns add H3                                      #adds the namespace H3
ip netns add R  									 #adds the namespace R

ip link add veth1 type veth peer name veth2          #add a virtual ethernet peer betwenn veth1 ane veth2
ip link add veth3 type veth peer name veth6          #add a virtual ethernet peer betwenn veth3 ane veth6
ip link add veth4 type veth peer name veth5          #add a virtual ethernet peer betwenn veth4 ane veth5
ip netns exec R brctl addbr br1 

sudo ip link set veth2 netns R                       #connects the veth interface veth2 to the namsespace R
sudo ip link set veth3 netns R                       #connects the veth interface veth3 to the namsespace R
sudo ip link set veth4 netns R                       #connects the veth interface veth4 to the namsespace R

ip link set veth1 netns H1                           #connects the veth interface veth1 to the namsespace H1
ip link set veth5 netns H3                           #connects the veth interface veth5 to the namsespace H3
ip link set veth6 netns H2                           #connects the veth interface veth6 to the namsespace H2

ip netns exec H1 ip address add 10.0.10.34/24 dev veth1  #assigning the ip address of veth1 to 10.0.10.34/24 in the namespace H1
ip netns exec H3 ip address add 10.0.30.34/24 dev veth5  #assigning the ip address of veth5 to 10.0.30.34/24 in the namespace H3
ip netns exec H2 ip address add 10.0.20.34/24 dev veth6  #assigning the ip address of veth1 to 10.0.20.34/24 in the namespace H2
ip netns exec R ip address add 10.0.10.1/24 dev veth2    #assigning the ip address of veth2 to 10.0.10.1/24 
ip netns exec R ip address add 10.0.20.1/24 dev veth3    #assigning the ip address of veth3 to 10.0.20.1/24 
ip netns exec R ip address add 10.0.30.1/24 dev veth4    #assigning the ip address of veth4 to 10.0.30.1/24                 


                   

ip netns exec H1 ip link set dev veth1 up            #in H1 setting up veth1
ip netns exec H2 ip link set dev veth6 up            #in H2 setting up veth6
ip netns exec H3 ip link set dev veth5 up            #in H3 setting up veth5
ip netns exec R ip link set dev veth2 up             #in R setting up veth2
ip netns exec R ip link set dev veth3 up             #in R setting up veth3
ip netns exec R ip link set dev veth4 up             #in R setting up veth4
ip netns exec R ip link set dev br1 up

ip netns exec R brctl addif br1 veth2 veth3 veth4   #in br1 bridge adding the interfaces veth2,veth3 and veth4



ip netns exec R sysctl -w net.ipv4.ip_forward=1                 #enables ip forwarding at R

ip netns exec H1 ip route add default via 10.0.10.34 dev veth1  #making 10.0.10.34 as default in H1
ip netns exec H2 ip route add default via 10.0.20.34 dev veth6  #making 10.0.20.34 as default in H2
ip netns exec H3 ip route add default via 10.0.30.34 dev veth5  #making 10.0.30.34 as default in H3

