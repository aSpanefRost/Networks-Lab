
if [[ $EUID -ne 0 ]];
	then echo "Run the script in superuser mode using 'sudo su'"  #this portion checks if the 
         exit $1                                                  #user is in super user mode or not

fi

#!/bin/bash
ip netns add ns1                                     #adds the namespace ns1
ip netns add ns2									 #adds the namespace ns2
ip link add Veth0 type veth peer name Veth1          #add a virtual ethernet peer betwenn Veth0 ane Veth1
ip link set Veth0 netns ns1                          #connects the veth interface Veth0 to the namsespace ns1
ip link set Veth1 netns ns2                          #connects the veth interface Veth0 to the namsespace ns1

ip netns exec ns1 ip link set dev Veth0 up           #in ns1 setting up Veth0
ip netns exec ns2 ip link set dev Veth1 up           #in ns2 setting up Veth1


ip netns exec ns1 ip address add 10.1.1.0/24 dev Veth0   #assigning the ip address of Veth0 to 10.1.1.0/24 in the namespace ns1
ip netns exec ns2 ip address add 10.1.2.0/24 dev Veth1   #assigning the ip address of Veth1 to 10.1.2.0/24 in the namespace ns2
ip -n ns1 route add 10.1.2.0/24 dev Veth0                #adding ip address 10.1.2.0/23 in the route table of the namespace ns1
ip -n ns2 route add 10.1.1.0/24 dev Veth1                #adding ip address 10.1.1.0/23 in the route table of the namespace ns2